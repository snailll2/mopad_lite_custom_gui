#! /bin/sh
export LD_LIBRARY_PATH=/customer/lib:/config/wifi/

# NSS DNS 模块修复: vendor 把 libnss_*.so.2 放在 /config/wifi,只靠上面的
# LD_LIBRARY_PATH 覆盖不到清洗环境的子进程(如 telnetd 登录 shell)→ getaddrinfo
# dlopen 失败 → busybox nslookup/ping/wget 全报 "bad address"。落到 /lib 默认
# 搜索路径 + 补 nsswitch.conf,所有动态进程都能解析;缺失才补,幂等。
for _nss in libnss_dns.so.2 libnss_files.so.2 libnss_db.so.2 libnss_hesiod.so.2; do
	[ -e "/lib/$_nss" ] || cp "/config/wifi/$_nss" /lib/ 2>/dev/null
done
[ -e /etc/nsswitch.conf ] || printf 'passwd: files\ngroup: files\nshadow: files\nhosts: files dns\nnetworks: files\nprotocols: files\nservices: files\n' > /etc/nsswitch.conf

# 设置缓冲队列的个数
sysctl -w net.unix.max_dgram_qlen=1000
ifconfig lo up

# Auto-start telnetd at boot (dev access, no TTL required); idempotent if rcS already started it.
[ -z "$(pidof telnetd)" ] && telnetd -l /bin/sh &

while [ ! -e /sys/class/net/wlan0 ] ; do
	echo "----------------wlan0 no  exist, sleep 1s--------------------"
	sleep 1
done

echo "------------------fw_printenv version----------------"
/etc/fw_printenv version
echo "-----------------------------------------------------"

TMP_PATH="/tmp"
UPGRADE_SH_NAME="upgrade.sh"
UPGRADE_FILE_DIR_NAME="zgw_upgrade"
APPLICATION_PATH="/customer"
UPGRADE_FILE_PATH="/customer/mopad_lite/upgrade.tar.bz2"
UPGRADE_INFO_FILE_NAME="upgrade_info.json"
DEBUG_FILE_NAME="debug"
SH_FILE="*.sh"

#判断是否存在upgrade_info.json，不存在则说明解压不正常，则不能进行文件拷贝，避免是解压一半的文件
if [ -e $UPGRADE_FILE_PATH ];then
	if [ -e $APPLICATION_PATH/$UPGRADE_INFO_FILE_NAME ];then
		echo "have find the $UPGRADE_INFO_FILE_NAME   ^v^"
		#解压升级脚本
		tar -jxvf $UPGRADE_FILE_PATH $UPGRADE_FILE_DIR_NAME/$UPGRADE_SH_NAME -C $TMP_PATH/

		#执行升级脚本，继续完成上次升级中途掉电而未完成的升级拷贝
		$TMP_PATH/$UPGRADE_FILE_DIR_NAME/upgrade.sh
	else
		echo "No find the $UPGRADE_INFO_FILE_NAME !"
		#优先删除upgrade_info.json，避免删除整个升级文件过程中失败或掉电
		rm $APPLICATION_PATH/$UPGRADE_INFO_FILE_NAME
		rm -rf $UPGRADE_FILE_PATH
		#认为解压不正常,退出，不执行拷贝
		echo "WARNING: upgrade fail!!!"
	fi
else
	#不存在升级文件夹则不需管
	echo "no find $UPGRADE_DIR ~ continue ex "
fi

if [ -e $DEBUG_FILE_NAME ];then
	ulimit -c unlimited
	echo "/tmp/core" > /proc/sys/kernel/core_pattern
fi

#配置coredump
if [ -e /customer/mopad_lite/core.sh ];then
	echo "have find core.sh, automatic packaging when the program crashes  ^v^"
	echo "|/customer/mopad_lite/core.sh" > /proc/sys/kernel/core_pattern
	chmod -c 777 /customer/mopad_lite/core.sh
fi

mkdir -p /tmp/www/cgi-bin

#-------------------------------------------------------------
# Mopai port (Aqara multi-screen dashboard):
#   if the ported UI is deployed, use it INSTEAD of the stock
#   LVGL UI; otherwise fall back to the original boot chain.
#-------------------------------------------------------------
if [ -x /data/scripts/mopad_lite_standalone_app ]; then
	echo "enter ported-ui mode"
	# note: do NOT start mopad_lite_reset_process watchdog here,
	# it would resurrect the stock LVGL UI and conflict on fb0.
	chmod +x /data/scripts/mopad_lite_standalone_app 2>/dev/null
	# (Wi-Fi status reads /customer/wpa_supplicant.conf directly in-app; no
	#  /tmp bridge needed.)
	# --- Web editor on 8080 (mirrors S1E post_init.sh) ---
	mkdir -p /tmp/www/cgi-bin
	cp -f /data/scripts/index.html /tmp/www/index.html 2>/dev/null
	cp -f /data/scripts/api.cgi /tmp/www/cgi-bin/api.cgi 2>/dev/null
	chmod +x /tmp/www/cgi-bin/api.cgi 2>/dev/null
	killall httpd 2>/dev/null
	httpd -p 8080 -h /tmp/www &
	# --- ha_daemon: wifi + device temp/hum (Si7021) + pushes mopad_lite
	#      entities to HomeAssistant; writes /tmp/ha_states.json for the app. ---
	killall feeder 2>/dev/null
	chmod +x /data/scripts/ha_daemon 2>/dev/null
	/customer/aqgui/scripts/ha_daemon >/tmp/ha_daemon.log 2>&1 &
	( cd /data/scripts; LD_LIBRARY_PATH=/lib:/customer/lib:/data/scripts \
		./mopad_lite_standalone_app >/tmp/aqgui.log 2>&1 & )
else
	echo "enter factory-ui mode"
	cd /customer;./mopad_lite_reset_process & > /dev/ttyS0 2>&1
	cd /customer;./ui_display.sh
	sleep 1
fi

#判断启动模式
cd /customer
if [ -e $DEBUG_FILE_NAME ];then
	echo "enter debug mode"
	./mopad_lite_app_process.bin debug & > /dev/ttyS0 2>&1
else
	echo "enter normal mode"
	./mopad_lite_app_process.bin & > /dev/ttyS0 2>&1
fi