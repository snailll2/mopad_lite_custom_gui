#!/bin/sh
# HTTPS fetch helper (OTA) — 摩派 Lite
# 优先走 curl(install.sh 持久化在 /data/scripts/curl),无 openssl 的固件也能拉 GitHub;
# openssl + http_body_strip 作为回退。镜像顺序: ghfast.top → cdn.jsdelivr.net → 直连。
# 更新仓库: snailll2/mopad_lite_custom_gui
HOST="$1"
PATH_URL="$2"
OUT_FILE="$3"
TIMEOUT="${4:-30}"

if [ -z "$HOST" ] || [ -z "$PATH_URL" ] || [ -z "$OUT_FILE" ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') [FETCH] Usage: $0 <host> <path> <outfile> [timeout]"
    exit 1
fi

TMP_OUT="${OUT_FILE}.tmp$$"
rm -f "$TMP_OUT"

CURL=""
if [ -x /data/scripts/curl ]; then
    CURL="/data/scripts/curl"
elif [ -x /tmp/curl ]; then
    CURL="/tmp/curl"
elif command -v curl >/dev/null 2>&1; then
    CURL="curl"
fi

do_get() {
    _h="$1"
    _p="$2"
    _to="${3:-10}"
    if [ -n "$CURL" ]; then
        "$CURL" -skfL --connect-timeout "$_to" -m $((_to + 30)) -o "$TMP_OUT" "https://${_h}${_p}" 2>/dev/null
        [ -s "$TMP_OUT" ] && return 0
    fi
    if command -v openssl >/dev/null 2>&1 && [ -x /data/scripts/http_body_strip ]; then
        printf "GET %s HTTP/1.0\r\nHost: %s\r\nUser-Agent: Mozilla/5.0 (S1E-OTA)\r\nConnection: close\r\n\r\n" "$_p" "$_h" | \
            timeout -t "$_to" openssl s_client -4 -servername "${_h}" -connect "${_h}:443" -quiet 2>/dev/null | \
            /data/scripts/http_body_strip > "$TMP_OUT"
        [ -s "$TMP_OUT" ] && return 0
    fi
    rm -f "$TMP_OUT"
    return 1
}

SUCCESS=0

# If target is raw.githubusercontent.com, use real-time accelerated proxy (ghfast.top) first
if [ "$HOST" = "raw.githubusercontent.com" ]; then
    GHF_PATH="/https://raw.githubusercontent.com${PATH_URL}"
    GHF_TO=8
    [ "$TIMEOUT" -gt 20 ] && GHF_TO="$TIMEOUT"
    if do_get "ghfast.top" "$GHF_PATH" "$GHF_TO"; then
        SUCCESS=1
    fi
fi

# Fallback to jsdelivr with @main for release repo
if [ "$SUCCESS" -eq 0 ] && [ "$HOST" = "raw.githubusercontent.com" ] && echo "$PATH_URL" | grep -q "^/snailll2/mopad_lite_custom_gui/main/"; then
    JSD_PATH="/gh/snailll2/mopad_lite_custom_gui@main/${PATH_URL#/snailll2/mopad_lite_custom_gui/main/}"
    JSD_TO=8
    [ "$TIMEOUT" -gt 20 ] && JSD_TO="$TIMEOUT"
    if do_get "cdn.jsdelivr.net" "$JSD_PATH" "$JSD_TO"; then
        SUCCESS=1
    fi
fi

# If proxy not applicable or failed, try direct host
if [ "$SUCCESS" -eq 0 ]; then
    if do_get "$HOST" "$PATH_URL" "$TIMEOUT"; then
        SUCCESS=1
    fi
fi

if [ "$SUCCESS" -eq 1 ] && [ -s "$TMP_OUT" ]; then
    mv -f "$TMP_OUT" "$OUT_FILE"
    exit 0
else
    rm -f "$TMP_OUT"
    exit 1
fi
